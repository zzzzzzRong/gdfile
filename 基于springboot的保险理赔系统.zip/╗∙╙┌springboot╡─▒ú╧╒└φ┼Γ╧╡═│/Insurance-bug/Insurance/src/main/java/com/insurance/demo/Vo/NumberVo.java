package com.insurance.demo.Vo;

/**
 * @USER: Mr.Wang
 * @DATE: 2020/2/6
 **/
public class NumberVo {
    private int menzhen;
    private int yisi;
    private int quezheng;
    private int zhiyu;
    private int siwang;

    public NumberVo() {
    }

    public int getMenzhen() {
        return menzhen;
    }

    public void setMenzhen(int menzhen) {
        this.menzhen = menzhen;
    }

    public int getYisi() {
        return yisi;
    }

    public void setYisi(int yisi) {
        this.yisi = yisi;
    }

    public int getQuezheng() {
        return quezheng;
    }

    public void setQuezheng(int quezheng) {
        this.quezheng = quezheng;
    }

    public int getZhiyu() {
        return zhiyu;
    }

    public void setZhiyu(int zhiyu) {
        this.zhiyu = zhiyu;
    }

    public int getSiwang() {
        return siwang;
    }

    public void setSiwang(int siwang) {
        this.siwang = siwang;
    }
}
