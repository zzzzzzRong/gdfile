package com.insurance.demo.Vo;

import lombok.Data;

/**
 * @USER: Mr.Wang
 * @DATE: 2020/2/7
 **/
@Data
public class StatVo {
    private int menzhen;
    private int yisi;
    private int quezheng;

}
