package com.insurance.demo.Vo;

import lombok.Data;

/**
 * @USER: Mr.Wu
 * @DATE: 2020/3/7
 **/
@Data
public class StatVo {
    private int menzhen;
    private int yisi;
    private int quezheng;

}
